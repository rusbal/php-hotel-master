<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing AuthenticateTestRequest
 */
class AuthenticateTestRequest extends ANetApiRequestType
{


}

