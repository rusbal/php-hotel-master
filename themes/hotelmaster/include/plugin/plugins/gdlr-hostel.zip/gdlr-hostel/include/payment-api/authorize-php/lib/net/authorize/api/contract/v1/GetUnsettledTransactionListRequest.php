<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing GetUnsettledTransactionListRequest
 */
class GetUnsettledTransactionListRequest extends ANetApiRequestType
{


}

